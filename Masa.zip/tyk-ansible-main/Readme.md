[![No Maintenance Intended](http://unmaintained.tech/badge.svg)](http://unmaintained.tech/)

# DEPRECATED
Please visit [TykTechnologies/tyk-ansible](https://github.com/TykTechnologies/tyk-ansible) instead.
