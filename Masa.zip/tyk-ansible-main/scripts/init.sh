cp ansible.cfg.example ansible.cfg
cp hosts.yml.example hosts.yml
ansible-galaxy install -r requirements.yml
